<?php

include 'header.php'; ?>

	<div id="page404">
			<table>
					<tbody>
						<tr>
								<td>
										<div class="caption">Page Not Found.</div>
										<div class="message">Sorry, there’s nothing here.<br>Visit <a class="front-page-link" href="/">front page</a>.</div>
								</td>
						</tr>
				</tbody>
			</table>
	</div>

<?php
include 'footer.php';