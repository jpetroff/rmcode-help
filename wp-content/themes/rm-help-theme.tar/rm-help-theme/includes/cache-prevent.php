<?php
function rm_build_timestamp() {
	return '1522323590344';
}