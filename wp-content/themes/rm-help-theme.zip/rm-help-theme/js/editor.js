(function(w){
"use strict";
// File /Users/john/rmsource/rmcode-help/_build/tinymce_js/main.js

console.log('!');
// End of /Users/john/rmsource/rmcode-help/_build/tinymce_js/main.js
})(window);