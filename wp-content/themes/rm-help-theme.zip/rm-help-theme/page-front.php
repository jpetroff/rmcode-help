<?php
/**
 * Template Name: Homepage
 */

include 'header.php';
?>
<?php show_search_component(); ?>
	<div class="_wrapper" id="app-page">
		
		<?php include 'helper-page-front.php' ?>
		
	</div>
<?php
include 'footer.php';
